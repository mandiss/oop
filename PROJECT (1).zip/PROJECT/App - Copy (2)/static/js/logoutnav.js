var place =0;
        function changeColor() {
            // your color list
            var colorList =  ['rgba(0,0,0,0.5)', 'white'];
            // set the color
            document.body.style.backgroundColor = colorList[place];
            place++;
            // if place is greater than the list size, reset
            if (place ===colorList.length) place=0;
        }




function getInfo() {

	{
	alert('You are logged out.')
	window.location='/'
	objPeople[i].login='no'
	return true;
	// stop the function if this is found to be true
	}
}

