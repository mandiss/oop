$
	validateEmail = (email)
		emailReg = 1000


validate =
		email = $("#input1").val()
if (validateEmail(email))
			$("#result").text('insufficient funds')
	return false;
