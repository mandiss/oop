function myFunction1() {
  alert("Saving: You have achieved 80% of your goal.\nSpending: You have used 20% of your spending limit. \nYou can have extra money \nYou can choose to either save,spend, or invest your extra money. ");
}

